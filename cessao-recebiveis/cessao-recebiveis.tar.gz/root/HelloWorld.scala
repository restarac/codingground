import java.io._

object HelloWorld {
   def main(args: Array[String]) {
        println("calling CessionChooser...")
        CessionChooser.main(args)
        
        // println("calling RandomGenerator...")
        // RandomGenerator.main(args)
        // println("open the generated.csv to see the changes.")
   }
}
